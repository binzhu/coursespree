<div class="left_content">
	<div class="sidebar_search">
		<form>
			<input type="text" name="" class="search_input" value="search keyword" onclick="this.value=''" />
			<input type="image" class="search_submit" src="images/search.png" />
		</form>            
	</div>

	<div class="sidebarmenu">
		<a class="menuitem submenuheader" href="">Subcategories</a>
		<div class="submenu">
			<ul>
				<li><a href="">Sidebar submenu</a></li>
				<li><a href="">Sidebar submenu</a></li>
				<li><a href="">Sidebar submenu</a></li>
				<li><a href="">Sidebar submenu</a></li>
				<li><a href="">Sidebar submenu</a></li>
			</ul>
		</div>
		<a class="menuitem" href="">User Reference</a>
	</div>
</div>
