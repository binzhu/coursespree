			</div><!-- end of right content-->
			<div class="clear"></div>
		</div><!--end of center content -->
		<div class="clear"></div>
	</div><!--end of main content-->

	<div class="footer">
		<!-- div class="left_footer">CourseSpree ADMIN PANEL</div -->
	</div>
</div><!--end of main container-->
</body>
</html>
