<?php
session_start();
ini_set('display_errors', 0);
require_once '../includes/db.php';
require_once 'menu.php';
require_once 'functions.php';
?>
